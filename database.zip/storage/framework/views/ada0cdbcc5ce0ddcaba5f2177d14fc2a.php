<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <h1><?php echo e($activity->title); ?></h1>

    <img src="<?php echo e(asset('storage/'.$activity->image)); ?>" width="300">

    <p><?php echo e($activity->description); ?></p>
    
    <p>Date: <?php echo e($activity->date); ?></p>
    <p>Location: <?php echo e($activity->location); ?></p>

    <?php
        $registration= \App\Models\Registration::where('user_id', auth()->id())
            ->where('activity_id', $activity->id)
            ->first();
    ?>

    <?php if($registration): ?>
        <?php if($registration->status == 'pending'): ?>
            <button disabled>รออนุมัติ</button>
        <?php elseif($registration->status == 'approved'): ?>
            <button disabled>สมัครแล้ว</button>
        <?php elseif($registration->status == 'rejected'): ?>
            <button disabled>ถูกปฏิเสธ</button>
       <?php endif; ?>
    <?php else: ?>
        <form method="POST" action="/activities/<?php echo e($activity->id); ?>/register">
           <?php echo csrf_field(); ?>
           <button type="submit">สมัครกิจกรรม</button>
       </form>
    <?php endif; ?>
    <?php if(auth()->user()->role === 'admin'): ?>
    <form method="POST" action="/admin/activities/<?php echo e($activity->id); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button style="background:red;">Delete activities</button>
    </form>
    <?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\activity-hub\resources\views/activities/show.blade.php ENDPATH**/ ?>