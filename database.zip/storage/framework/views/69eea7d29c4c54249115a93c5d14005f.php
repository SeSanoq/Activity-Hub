<!DOCTYPE html>
<html>
<head>
    <title>All Activities</title>
</head>
<body>

<h1>All Activities</h1>

<?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div style="border:1px solid black; padding:10px; margin:10px;">

    <h2><?php echo e($activity->title); ?></h2>

    <?php if($activity->image): ?>
    <img src="<?php echo e(asset('storage/' . $activity->image)); ?>" width="300">
    <?php endif; ?>

    <p><?php echo e($activity->description); ?></p>

    <p>Date: <?php echo e($activity->date); ?></p>

    <p>Location: <?php echo e($activity->location); ?></p>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\activity-hub\resources\views/activities/index.blade.php ENDPATH**/ ?>